<?php
$server = "127.0.0.1";      //Ip_Server
$user = "root";          //Name_User
$password = "";          //Constraseña
$bd = "bd_dulce_sabor"; //BD
?>