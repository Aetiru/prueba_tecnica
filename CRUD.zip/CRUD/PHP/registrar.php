<?php
    include('connect.php');

    
    //Registrar
    if(!empty($_POST)){
        if(isset($_POST["button"])){
            //Recuperamos Variables
            $N_Producto = mysqli_real_escape_string($conexion, $_POST['N_Producto']);
            $V_Unit = mysqli_real_escape_string($conexion, $_POST['V_Unit']);
            $Stock = mysqli_real_escape_string($conexion, $_POST['Stock']);

            $sql_register = "INSERT INTO producto(Nam_Fruta, Valor_Unit, Stock)
                            VALUES ('$N_Producto', '$V_Unit', '$Stock')";
            $result_register = $conexion->query($sql_register);
            if($result_register > 0 ){
                echo "<script> 
                        alert('Producto Registrado con Exito');
                        window.location = './index.php';
                        </script>";
            }else{
                echo "<script> 
                        alert('Error al Registrar el Producto');
                        window.location = 'index.php';
                        </script>";
                
            }
        }
    }

    //Obtner
    //Sentencia

            $sql_consulta = "SELECT * FROM producto";
            $sql_preparar = $conexion->prepare($sql_consulta);
            $sql_preparar->execute();
            $frutas = $sql_preparar->fetchAll();


    
        //Editar
        if(!empty($_POST)){
            if(isset($_POST["buscar"])){
                //Recuperamos Variables
                $id = mysqli_real_escape_string($conexion, $_POST['Id']);
            
    
                $sql_register = "SELECT * FROM producto WHERE Id = '$id'";
                $result_register = $conexion->query($sql_register);
                if($result_register > 0 ){
                    
                }
            }
        }






?>