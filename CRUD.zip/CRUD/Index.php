<html>
    <head>
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <style>
            
           
        </style>


    </head> 

    </head>
    <body >
        <h5>Frutera Dulce Sabor</h5>
        <form action="" method="POST">
            <div id="contenedor">
                
                    <button type="submit" class="" name="button" ><a href="registrar.php">Registrar Producto</a></button>
                    
                
                    <button type="submit" class="" name="button" ><a href="obtener.php">Obtener</a></button>
                    <button type="submit" class="" name="button" ><a href="Editar.php">Editar</a></button>
                    <button type="submit" class="" name="button" ><a href="Eliminar.php">Eliminar</a></button>
                    
                
            </div>
        </form>
    </body>
</html>