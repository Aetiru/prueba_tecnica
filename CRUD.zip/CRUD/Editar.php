<html>
    <head>
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    </head> 

    </head>
    <body>
    <form action="php/registrar.php" method="POST">
        <div class="form-row">
            
        <div class="form-group col-md-6">
        <div class="form-group col-md-6">
                
                <label for="inputEmail4">Id</label>
                <input type="text" class="form-control" id="producto" placeholder="Nombre del Producto" name="Id">
                </div>
            <label for="inputEmail4">Nombre del Producto</label>
            <input type="text" class="form-control" id="producto" placeholder="Nombre del Producto" name="N_Producto">
            </div>
            <div class="form-group col-md-6">
            <label for="inputPassword4">Valor Unitario</label>
            <input type="text" class="form-control" id="Valor Unitario" placeholder="Valor Unitario" name="V_Unit">
            </div>
        </div>
        <div class="form-group">
            <label for="inputAddress">Stock</label>
            <input type="text" class="form-control" id="Stock" placeholder="Stock" name="Stock">
        </div>
         </div>
        <button type="submit" class="btn btn-primary" name="button">Registrar Producto</button>
        </form>
    </body>
</html>