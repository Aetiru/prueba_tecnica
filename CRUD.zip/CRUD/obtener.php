<html>
    <head>
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    </head> 
    <body>
        <h5>obtener Producto</h5>
        <table class="table">
  <thead>
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Nombre de la Fruta</th>
      <th scope="col">Valor Unitario</th>
      <th scope="col">Stock</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      
    
    <?php
    include('php/registrar.php');

          if ($frutas && $sentencia->rowCount() > 0) {
            foreach ($frutas as $fila) {
              ?>
              <tr>
                <td><?php echo escapar($fila["Id"]); ?></td>
                <td><?php echo escapar($fila["Nam_Frutas"]); ?></td>
                <td><?php echo escapar($fila["Valor_Unit"]); ?></td>
                <td><?php echo escapar($fila["Stock"]); ?></td>
              </tr>
              <?php
            }
          }
          ?>
          </tr>
  </tbody>
</table>
    </body>
</html>